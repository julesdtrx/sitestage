<?php
session_abort();
session_start();
include "../inc/header_security.inc";
define("PATH", "/");
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur 404</title>
    <meta name="description" content="Page de erreur 404">
    <link rel="stylesheet" href="<?= PATH ?>style/style.css">
    <style>
        main { height: 100vh; }
    </style>
</head>
<body>
<div class="bg">
    <main>
        <article>
            <h2>Erreur 404 : </h2>
            <h4> Page non trouvée, veuillez retournez à l'accueil</h4>
        </article>
    </main>
</div>

</body>
</html>
