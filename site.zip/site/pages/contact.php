<?php 
include "../inc/header_security.inc";
$title="Contactez-nous";
$desc="Page de contact, vous pouvez nous envoyer un message";

include "../inc/top.inc";
?>
<main>
    <article>
        <h2>Nous contacter :</h2>
        <form action="traitement_contact.php" method="post">
            <!-- <input type="hidden" name="id" id="id" value="<?= $_SESSION['id']?>"> -->
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken(); ?>">
            <input type="text" name="objet" id="objet" placeholder="Objet du message..">
            <textarea name="message" id="message" rows="6" cols="55" placeholder="Votre message.." required></textarea>
            <input type="hidden" name="utilisateur" value="<?= $_SESSION['user']?>">
            <input type="submit" name="submit" value="Envoyer le message">
        </form>
        <?php if (isset($_SESSION["ajout"])){echo "<p>".$_SESSION["ajout"]."</p>"; unset($_SESSION["ajout"]);}?>
    </article>
</main>
<?php include '../inc/bottom.inc'?>