<?php
session_abort();
session_start();
include "../inc/header_security.inc";
define("PATH", "/");
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <meta name="description" content="Page de création de compte">
    <link rel="stylesheet" href="<?= PATH ?>style/style.css">
    <style>
        main { height: 100vh; }
        .criteria { color: red; font-size: 13px;}
        .valid { color: green; font-size: 13px;}
        main article{
            margin-top: 5vh;
            height: auto;
            max-height:none;
        }
    </style>
</head>
<body>
<div class="bg">
    <main>
        <article>
            <h2>S'inscrire</h2>
            <form action="traitement_inscription.php" method="post" id="inscriptionForm">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken(); ?>">
                <p>Nom d'utilisateur :</p>
                <input type="text" name="user" id="user" placeholder="Nom d'utilisateur" maxlength="150" autocomplete="name">
                <p>Adresse mail :</p>
                <input type="text" name="email" id="email" placeholder="Adresse mail.." maxlength="150" autocommplete="mail">
                <p>Mot de passe :</p>
                <input type="password" name="password" id="password" placeholder="Mot de passe..." maxlength="150" autocomplete="country">
                <p>Le mot de passe doit comprendre :</p>
                <ul id="passwordCriteria">
                    <li id="length" class="criteria">- Au moins 8 caractères</li>
                    <li id="number" class="criteria">- Au moins 1 chiffre</li>
                    <li id="lowercase" class="criteria">- Au moins 1 lettre minuscule</li>
                    <li id="uppercase" class="criteria">- Au moins 1 lettre majuscule</li>
                    <li id="special" class="criteria">- Au moins 1 caractère spécial</li>
                </ul>
                <p>Confirmer le mot de passe :</p>
                <input type="password" name="password1" id="password1" placeholder="Mot de passe..." maxlength="150">
                <input type="submit" value="S'inscrire" name="submit" id="submitBtn" disabled>
                <p>Déjà un compte ? Se connecter <a href="connexion.php">ici</a>.</p>
            </form>
            <?php
            if (isset($_SESSION['message'])) {
                echo "<p>" . $_SESSION['message'] . "</p>";
                unset($_SESSION['message']);
            }
            ?>
        </article>
    </main>
        </div>
<script  nonce="<?= $nonce ?>">
    document.getElementById('password').addEventListener('input', function() {
        var password = document.getElementById('password').value;
        var lengthCriteria = document.getElementById('length');
        var numberCriteria = document.getElementById('number');
        var lowercaseCriteria = document.getElementById('lowercase');
        var uppercaseCriteria = document.getElementById('uppercase');
        var specialCriteria = document.getElementById('special');
        var submitBtn = document.getElementById('submitBtn');
        var lengthValid = password.length >= 8;
        var numberValid = /[0-9]/.test(password);
        var lowercaseValid = /[a-z]/.test(password);
        var uppercaseValid = /[A-Z]/.test(password);
        var specialValid = /[\W_]/.test(password);
        updateCriteria(lengthCriteria, lengthValid);
        updateCriteria(numberCriteria, numberValid);
        updateCriteria(lowercaseCriteria, lowercaseValid);
        updateCriteria(uppercaseCriteria, uppercaseValid);
        updateCriteria(specialCriteria, specialValid);
        var allValid = lengthValid && numberValid && lowercaseValid && uppercaseValid && specialValid;
        submitBtn.disabled = !allValid;
    });
    function updateCriteria(element, isValid) {
        if (isValid) {
            element.classList.remove('criteria');
            element.classList.add('valid');
        } else {
            element.classList.remove('valid');
            element.classList.add('criteria');
        }
    }
</script>
</body>
</html>
