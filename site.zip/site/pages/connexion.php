<?php
session_start();
include "../inc/header_security.inc";
$_SESSION["connect"]=0;
define("PATH", "/");
?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de connexion</title>
    <meta name="description" content="Connectez vous à votre compte">
    <link rel="stylesheet" href="<?=PATH?>style/style.css">
</head>
<body>
<div class="bg">
<main>
<style> main{height:100vh;}</style>
    <article>
        <h2>Se connecter</h2>
        <form action="traitement_connexion.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken(); ?>">
            <p>Nom d'utilisateur :</p>
            <input type="text" name="user" id="user" placeholder="Nom d'utilisateur" maxlength=150>
            <p>Mot de passe :</p>
            <input type="password" name="password" id="password" placeholder="Mot de passe..." maxlength=150>
            <input type="submit" value="Se connecter" name="submit">
            <p>Pas de compte ? S'inscrire <a href="inscription.php">ici </a>.</p>
        </form>
        <?php if (isset($_SESSION['message'])){
                echo "<p>".$_SESSION['message']."</p>";
                unset($_SESSION['message']);
            }?>
    </article>
</main>
</div>
</body>
</html>
