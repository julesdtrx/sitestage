<?php
include "../inc/header_security.inc";
session_start();

require '../vendor/autoload.php';
use Firebase\JWT\JWT;

if (!isset($_POST["verif"]) || empty($_POST["verif"])) {
    $_SESSION["message"] = "Tu as mal rempli le code de verification.";
    header("Location: connexion.php");
    exit;
} 

$code_verif = filter_input(INPUT_POST, 'verif', FILTER_VALIDATE_INT);

// Vérification si le code de vérification est valide
if ($code_verif === false) {
    $_SESSION["message"] = "Tu as mal rempli le code de verification.";
    header("Location: connexion.php");
    exit;
}

if ($code_verif == $_SESSION["code_verification"]) {
    $_SESSION["connect"] = 1;
    header("Location: ../index.php");
    exit;
} else {
    $_SESSION["message"] = "Mauvais code de vérification.";
    header("Location: connexion.php");
    exit;
}
?>
