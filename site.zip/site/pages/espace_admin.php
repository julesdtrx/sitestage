<?php include '../inc/header_security';if (session_status() == PHP_SESSION_NONE || $_SESSION["grade"] != 1 ) {
    header("Location : /site/pages/connexion.php");
}?>

<style>
main article form input{
    font-size: 10px;
    height:3em;
    text-align:center;
}
main article form p{
    width: 2%;
    margin: 0px 2em;
}
main article form .dom, main article form .ext{
    display:flex;
    width: 40%;
}
main article form{
    display:flex;
    justify-content:center;
    flex-wrap:wrap;
}
main article form input[name="score1"],main article form input[name="score2"]{
    width: 20px;
    text-align:center;
}
main article h3{
    width: 100%;
    text-align: center;
    margin: 1em 0;
}


</style>

<h3>Ajout de match :</h3>
<form action="traitement_espace_admin.php" method="post">
    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken(); ?>">
    <div class="dom">
        <input type="text" name="equipe1" id="equipe1" placeholder="Equipe DOM">
        <input type="text" name="score1" id="score1" placeholder="Score DOM">
    </div>
    <p> - </p>
    <div class="ext">
        <input type="text" name="score2" id="score2" placeholder="Score EXT">
        <input type="text" name="equipe2" id="equipe2" placeholder="Equipe EXT">
    </div>
    <br>
    <input type="submit" value="Ajouter le match" name="ajouter_match">
</form>
<?php if (isset($_SESSION["ajout"])){echo $_SESSION["ajout"];unset($_SESSION["ajout"]);}?>