<?php
include "../inc/header_security.inc";
define("PATH", "/");
session_start();
define("PATH", "/");
if ($_SESSION["preconnection"] != 1){
    header("Location: /pages/connexion.php");
} else{};?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de vérification</title>
    <meta name="description" content="Vérifiez votre compte">
    <link rel="stylesheet" href="<?=PATH?>style/style.css">
</head>
<body>
<div class="bg">
<main>
<style> main{height:100vh;}</style>
    <article>
        <h2>Code de vérification</h2>
        <h3>Entrer le code envoyés à l'adresse <?=$_SESSION["email"]?>.</h3>
        <form action="traitement_verif.php" method="post">
            <p>Code de vérification :</p>
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken(); ?>">
            <input type="text" name="verif" id="verif" placeholder="Code de verification" maxlength=150>
            <input type="submit" value="Se connecter" name="submit">
        </form>
    </article>
</main>
</div>
</body>
</html>
