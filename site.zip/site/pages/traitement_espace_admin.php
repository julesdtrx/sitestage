<?php include "../inc/header_security.inc";
session_start();
if (isset($_POST["equipe1"]) && !empty($_POST["equipe1"]) &&
    isset($_POST["equipe2"]) && !empty($_POST["equipe2"]) && 
    isset($_POST["score1"]) && is_numeric($_POST["score1"]) && 
    isset($_POST["score2"]) && is_numeric($_POST["score2"])
) {
    require_once '../inc/connexiondb.inc';
    $equipe1=filter_input(INPUT_POST,'equipe1');
    $score1=filter_input(INPUT_POST,'score1',FILTER_VALIDATE_INT);
    $score2=filter_input(INPUT_POST,'score2',FILTER_VALIDATE_INT);
    $equipe2=filter_input(INPUT_POST,'equipe2');
    $date=date('d/m/Y');
    $sql = $cle->prepare("INSERT INTO matchs(date,team1,team2,scoreteam1,scoreteam2) VALUES (:date,:equipe1,:equipe2,:score1,:score2);");
    $sql->bindParam(":date",$date);
    $sql->bindParam(":equipe1",$equipe1);
    $sql->bindParam(":score1",$score1);
    $sql->bindParam(":score2",$score2);
    $sql->bindParam(":equipe2",$equipe2);
    if ($sql->execute()){
        $_SESSION["ajout"]="Ajout du match effectué.";
        header("Location:compte.php");
    }
    
} 
else{
    $_SESSION["ajout"]="Erreur lors de l'insertion du nouveau produit dans la base de donnée.";
    header("Location:compte.php");
}