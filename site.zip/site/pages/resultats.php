<?php include "../inc/header_security.inc";
$title="Nos resultats";
$desc="Affichage de tous les résultats, avec date";
include "../inc/top.inc";
?>
<main>
    <style> 
    main{
        min-height: 92vh;
        height: auto;
    }
    main article{
        min-height:auto;
        height: auto;
        margin-bottom: 5em;
    }
    </style>
    <article>
        <h2>Les résultats :</h2>
        <table>
            <thead>
                <tr>
                    <th>Date :</th>
                    <th>Equipe DOM :</th>
                    <th>Score DOM :</th>
                    <th></th>
                    <th>Score EXT :</th>
                    <th>Equipe EXT :</th>
                </tr>
            </thead>
            <tfoot></tfoot>
            <tbody>
                <?php include '../inc/connexiondb.inc';
                $requete='SELECT date,team1,team2,scoreteam1,scoreteam2 FROM matchs;';
                $liste_match=$cle->query($requete);
                foreach ($liste_match as $m){
                    echo "<tr>
                    <td>".$m[0]."</td>
                        <td name='equipedom'>".$m[1]."</td>
                        <td>".$m[3]."</td>
                        <td> - </td>
                        <td>".$m[4]."</td>
                        <td name='equipeext'>".$m[2]."</td>
                    </tr>";}?>
            </tbody>
            
    </table>
    </article>
    
</main>
<?php include '../inc/bottom.inc'?>