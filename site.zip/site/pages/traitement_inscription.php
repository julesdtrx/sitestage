<?php
// include "../inc/header_security.inc";
session_start();
if (!isset($_POST["user"]) || empty($_POST["user"])
    ||
    !isset($_POST["password"]) || empty($_POST["password"])
    ||
    !isset($_POST["email"]) || empty($_POST["email"])
){
    $_SESSION["message"] = "Tu dois correctement remplir le formulaire.";
    header("Location: inscription.php");
}
else{
    if (filter_input(INPUT_POST, 'user') == FALSE && filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL) == FALSE){
        $_SESSION["message"] = "Tu dois rentrer une adresse mail correcte.";
        header("Location: inscription.php");
    }
    else{
        if ($_POST["password"] != $_POST["password1"]){
            $_SESSION["message"]="Les mots de passe doivent être identiques.";
            header("Location:inscription.php");
        }
        else{
            function validatePassword($password) {
                $regex = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';
                return preg_match($regex, $password);
            }
            if (!validatePassword($_POST["password"])){
                $_SESSION["message"]= "Le mot de passe ne répond pas aux critères de sécurité.";
                header("Location: inscription.php");
            }
            else{
                require_once '../inc/connexiondb.inc';
    
                $user = filter_input(INPUT_POST, "user");
                $password = filter_input(INPUT_POST,"password");
                $email = filter_input(INPUT_POST,"email",FILTER_SANITIZE_EMAIL);
                $salt= bin2hex(random_bytes(16));
                $salted_password= $salt . $password;
                $hashed_password = hash('sha256', $salted_password);
    
                $sql = " INSERT INTO utilisateurs (username, email, salt, password) VALUES (:user, :email, :salt, :password); ";
                $stmt = $cle->prepare($sql);
                $stmt->bindParam(':user', $user);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':salt', $salt);
                $stmt->bindParam(':password', $hashed_password);
                if ($stmt->execute()){
                    header("Location:connexion.php");
                    $_SESSION["message"]="Inscription réussi, veuillez vous connecter.";
                }
                else{
                    header("Location: inscription.php");
                    $_SESSION["message"]="Problème lors de l'inscription, veuillez réessayer.";
                }
            }
        }
    }
}   