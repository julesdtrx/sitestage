<?php
include "../inc/header_security.inc";
session_start();
if (!isset($_POST["user"]) || empty($_POST["user"])
    ||
    !isset($_POST["password"]) || empty($_POST["password"])
){
    $_SESSION["message"] = "Tu dois correctement remplir le formulaire.";
    header("Location: connexion.php");
    exit;
}
else{
    if (filter_input(INPUT_POST, 'user') === false){
        $_SESSION["message"] = "Tu dois rentrer un nom d'utilisateur correct.";
        header("Location: connexion.php");
        exit;
    }
    else{
        require_once '../inc/connexiondb.inc';

        $user = filter_input(INPUT_POST, "user");
        $password = $_POST["password"];

        $sql = "SELECT username, email, password, grade FROM utilisateurs WHERE username = :user";
        $stmt = $cle->prepare($sql);
        $stmt->bindParam(':user', $user);
        $stmt->execute();
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($resultat && password_verify($password, $resultat["password"])){
            $_SESSION["user"] = $user;
            $_SESSION["connect"] = 1;
            $_SESSION["grade"] = $resultat["grade"];
            $_SESSION["email"] = $resultat["email"];
            header("Location: ../index.php");
            exit;
        }
        else{
            $_SESSION["message"] = "Utilisateur ou mot de passe incorrect.";
            header("Location: connexion.php");
            exit;
        }
    }
}
