<?php include "../inc/header_security.inc";
session_start();
if (isset($_POST["objet"]) && !empty($_POST["objet"]) &&
    isset($_POST["message"]) && !empty($_POST["message"]) &&
    isset($_POST["utilisateur"]) && !empty($_POST["utilisateur"]))
    {
    require_once '../inc/connexiondb.inc';
    $utilisateur=filter_input(INPUT_POST,'utilisateur');
    $objet=filter_input(INPUT_POST,'objet');
    $message=filter_input(INPUT_POST,'message');
    $date=date('d/m/Y - h:m:s');
    $sql = $cle->prepare("INSERT INTO contact(utilisateur,date,objet,message) VALUES (:utilisateur,:date,:objet,:message);");
    $sql->bindParam(":utilisateur",$utilisateur);
    $sql->bindParam(":date",$date);
    $sql->bindParam(":objet",$objet);
    $sql->bindParam(":message",$message);
    if ($sql->execute()){
        $_SESSION["ajout"]="Message envoyé !";
        header("Location:contact.php");
    }
    
} 
else{
    $_SESSION["ajout"]="Erreur lors de l'envoi du message.";
    header("Location:contact.php");
}