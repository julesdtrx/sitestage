<?php
include "../inc/header_security.inc";
session_start();

// Charger l'autoloader de Composer
require '../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_POST["user"]) || empty($_POST["user"]) ||
    !isset($_POST["password"]) || empty($_POST["password"])) {
    $_SESSION["message"] = "Tu dois correctement remplir le formulaire.";
    header("Location: connexion.php");
    exit;
} else {
    if (filter_input(INPUT_POST, 'user') === false) {
        $_SESSION["message"] = "Tu dois rentrer un nom d'utilisateur correct.";
        header("Location: connexion.php");
        exit;
    } else {
        require_once '../inc/connexiondb.inc';

        $user = filter_input(INPUT_POST, "user", FILTER_SANITIZE_STRING);
        $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_STRING);

        $sql = "SELECT username, email, salt, password, grade FROM utilisateurs WHERE username = :user";
        $stmt = $cle->prepare($sql);
        $stmt->bindParam(':user', $user);
        $stmt->execute();
        $resultat = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($resultat) {
            $salt = $resultat["salt"];
            $hashed_password = hash('sha256', $salt . $password);

            if ($hashed_password === $resultat["password"]) {
                $code_verification = rand(100000, 999999);
                $_SESSION["user"] = $user;
                $_SESSION["grade"] = $resultat["grade"];
                $_SESSION["email"] = $resultat["email"];
                $_SESSION["code_verification"] = $code_verification;

                // Envoyer l'email de vérification
                $destinataire = $resultat["email"];
                $sujet = "Code de verification - site de Jules";
                $message = "Bonjour $user,\n\nVotre code de verification est : $code_verification\n\n";


                $mail = new PHPMailer(true);
                try {
 
                    $mail->isSMTP();
                    $mail->Host = 'ssl0.ovh.net';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'julessmtp@ouicodeurs.me';
                    $mail->Password = 'x@_sG6P63x';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = 465;

                    $mail->setFrom('julessmtp@ouicodeurs.me', 'StageJulesOuiCoding');
                    $mail->addAddress($destinataire);
                    $mail->Subject = $sujet;
                    $mail->Body = $message;
                    $mail->send();
                    $_SESSION["preconnection"]=1;
                    header("Location: verify.php");
                    exit;
                } catch (Exception $e) {
                    $_SESSION["message"] = "Erreur lors de l'envoi du mail : {$mail->ErrorInfo}";
                    header("Location: connexion.php");
                    exit;
                }
            } else {
                $_SESSION["message"] = "Utilisateur ou mot de passe incorrect.";
                header("Location: connexion.php");
                exit;
            }
        } else {
            $_SESSION["message"] = "Utilisateur ou mot de passe incorrect.";
            header("Location: connexion.php");
            exit;
        }
    }
}
?>
