<?php
include "../inc/header_security.inc";
$title="Votre compte";
$desc="Page de votre compte, vos informations";
include "../inc/top.inc";
?>
<main>
    <article>
        <h2>Bonjour <?=$_SESSION["user"]?> :</h2>
        
        <ul>
            <li>Votre status : <?php if ($_SESSION["grade"] == 1)
            {echo "Administrateur";} else{ echo "Client";}?></li>
            <li>Se deconnecter : <div class="form-deco"><form action="traitement_deconnexion.php" method="post">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken(); ?>">
                <input type="image" src="../media/exit.svg" alt="porte pour se deconnecter">
            </form></div></li>
        </ul>
        <?php if ($_SESSION["grade"] == 1){
            include 'espace_admin.php';
        }?>
    </article>
</main>
<?php include '../inc/bottom.inc'?>