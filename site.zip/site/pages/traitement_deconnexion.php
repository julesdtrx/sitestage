<?php include "../inc/header_security.inc";
session_abort();
header("Location: /pages/connexion.php");
