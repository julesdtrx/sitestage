<?php
include "inc/header_security.inc";
$title="Menu principal";
$desc="Accueil du site";
include "inc/top.inc";


?>
    
        <main>
            <article>
                <h2>Résultat du dernier match :</h2>
                <div class="resultat-dernier">
                <?php include 'inc/connexiondb.inc';
                $requete='SELECT date,team1,team2,scoreteam1,scoreteam2 FROM matchs ORDER BY id DESC LIMIT 1;';
                $dernier_match=$cle->query($requete);
                foreach ($dernier_match as $m){
                    echo "<h3>".$m[1]." ".$m[3]." - ".$m[4]." ".$m[2]."</h3<<br><h6> Date de la rencontre : ".$m[0]."</h6>";
                }?>
                </div>

            </article>
        </main>
        <aside>
            <article>
                <h2>Actualités</h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis, voluptatum quis doloremque consectetur debitis enim perferendis, quaerat sint illo quo ex. Aperiam eaque quibusdam aut aliquam veniam, ad id minima? <br><br> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe, quis. Atque eius ex voluptatibus quidem eligendi tenetur animi totam fugiat praesentium, temporibus quod, unde natus quibusdam quaerat dolores, quia odio.</p>
            </article>
            <article>
                <h2>Les réseaux sociaux</h2>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Facilis, voluptatum quis doloremque consectetur debitis enim perferendis, quaerat sint illo quo ex. Aperiam eaque quibusdam aut aliquam veniam, ad id minima? <br><br> Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe, quis. Atque eius ex voluptatibus quidem eligendi tenetur animi totam fugiat praesentium, temporibus quod, unde natus quibusdam quaerat dolores, quia odio.</p>
            </article>
        </aside>
<?php include 'inc/bottom.inc'?>
